package Modles;

public class Assignjob {
    
  
    public String job;
    int vehicle;
    int emp;
    String date;
  
public Assignjob(String job, int vehicle, int emp,String date ){
        this.job = job;
        this.vehicle = vehicle;
        this.emp = emp;
        this.date=date;
       }
public Assignjob() {
        throw new UnsupportedOperationException("Can't Assign the employee");
}


    public String getjob(){
        return job;
    }
 
    public int getvehicle(){
        return vehicle;
    }
 
    public int getemp(){
        return emp;
    }
     public String getdate(){
      return date;
  }
    
}
  

