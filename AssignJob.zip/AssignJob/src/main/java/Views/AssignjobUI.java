package Views;
import Modles.Assignjob;
import javax.swing.JOptionPane;

public class AssignjobUI extends javax.swing.JFrame {

   
    public AssignjobUI() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        selectjob = new javax.swing.JComboBox<>();
        lable3 = new javax.swing.JLabel();
        selectemp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        selectvehicle = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        selectdate = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title.setFont(new java.awt.Font("Trebuchet MS", 3, 24)); // NOI18N
        title.setText("Assigning Workers For Jobs");
        jPanel1.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 380, 60));

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Select the job");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        selectjob.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Repair", "Restoration", " " }));
        selectjob.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectjobActionPerformed(evt);
            }
        });
        jPanel2.add(selectjob, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 310, -1));

        lable3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lable3.setText("Select an employee");
        jPanel2.add(lable3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 140, -1));

        selectemp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectempActionPerformed(evt);
            }
        });
        jPanel2.add(selectemp, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 310, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Select a vehicle");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 110, -1));
        jPanel2.add(selectvehicle, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 310, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Select a date");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 110, -1));
        jPanel2.add(selectdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 310, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 330, 300));

        jScrollPane1.setBackground(new java.awt.Color(255, 204, 204));

        jTable1.setBackground(new java.awt.Color(204, 255, 153));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "job", "Employee_ID", "Vehicle_ID", "Data", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 80, 470, 400));

        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 410, -1, -1));

        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 410, 70, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selectjobActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectjobActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_selectjobActionPerformed

    private void selectempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectempActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_selectempActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            String job = selectjob.getSelectedItem().toString();
            int emp=Integer.parseInt(selectemp.getText());
            int vehicle=Integer.parseInt(selectvehicle.getText());
            String date=selectdate.getText();
            JOptionPane.showMessageDialog(rootPane, "Submitted");
        }catch(Exception e) {
            JOptionPane.showMessageDialog(rootPane, "There is an Error");
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AssignjobUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AssignjobUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AssignjobUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AssignjobUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AssignjobUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lable3;
    private javax.swing.JTextField selectdate;
    private javax.swing.JTextField selectemp;
    private javax.swing.JComboBox<String> selectjob;
    private javax.swing.JTextField selectvehicle;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
